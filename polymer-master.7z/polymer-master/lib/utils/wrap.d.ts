// tslint:disable:variable-name Describing an API that's defined elsewhere.

export const wrap: <T extends Node>(node: T) => T;
